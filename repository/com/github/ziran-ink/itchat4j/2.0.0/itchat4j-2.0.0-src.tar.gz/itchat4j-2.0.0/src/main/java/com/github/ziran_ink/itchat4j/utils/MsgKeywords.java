package com.github.ziran_ink.itchat4j.utils;

public class MsgKeywords {
	public static String newFriendStr = "我通过了你的朋友验证请求";

}
